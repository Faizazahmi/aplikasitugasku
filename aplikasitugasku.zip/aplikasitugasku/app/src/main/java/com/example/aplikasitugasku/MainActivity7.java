package com.example.aplikasitugasku;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity7 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        }; public void back(View view) {
        Intent intent = new Intent(MainActivity7.this, MainActivity5.class);
        startActivity(intent);

    }; public void imageButton11(View view) {
        Intent intent = new Intent(MainActivity7.this, MainActivity9.class);
        startActivity(intent);

    };public void imageButton12(View view) {
            Intent intent = new Intent(MainActivity7.this, MainActivity5.class);
            startActivity(intent);
    }
}