package com.example.aplikasitugasku;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity11 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main11);

        };public void imageButton25(View view) {
        Intent intent = new Intent(MainActivity11.this, MainActivity10.class);
        startActivity(intent);

    };public void imageButton26(View view) {
        Intent intent = new Intent(MainActivity11.this, MainActivity12.class);
        startActivity(intent);

    };public void imageButton27(View view) {
        Intent intent = new Intent(MainActivity11.this, MainActivity10.class);
        startActivity(intent);
    }
}