package com.example.aplikasitugasku;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity15 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main15);

        };public void imageButton17(View view) {
        Intent intent = new Intent(MainActivity15.this, MainActivity16.class);
        startActivity(intent);

    };public void imageButton16(View view) {
        Intent intent = new Intent(MainActivity15.this, MainActivity5.class);
        startActivity(intent);
    }
}