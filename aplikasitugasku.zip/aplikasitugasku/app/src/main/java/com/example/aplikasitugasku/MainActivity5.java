package com.example.aplikasitugasku;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class MainActivity5 extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private Button groupButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        drawerLayout = findViewById(R.id.drawer_layout);
        groupButton = findViewById(R.id.Button2);

        groupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.END);
            }
        });

    }

    public void barcode(View view) {
        Intent intent = new Intent(MainActivity5.this, MainActivity7.class);
        startActivity(intent);

    }

    public void slide2(View view) {
        Intent intent = new Intent(MainActivity5.this, MainActivity7.class);
        startActivity(intent);

    };public void imageButton7(View view) {
        Intent intent = new Intent(MainActivity5.this, MainActivity14.class);
        startActivity(intent);

    };public void imageButton18(View view) {
            Intent intent = new Intent(MainActivity5.this, MainActivity15.class);
            startActivity(intent);
    }
}