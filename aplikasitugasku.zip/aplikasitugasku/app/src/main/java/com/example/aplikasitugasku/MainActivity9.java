package com.example.aplikasitugasku;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity9 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main9);

        };public void imageButton19(View view) {
        Intent intent = new Intent(MainActivity9.this, MainActivity7.class);
        startActivity(intent);

    }; public void imageButton20(View view) {
        Intent intent = new Intent(MainActivity9.this, MainActivity10.class);
        startActivity(intent);

    };public void imageButton21(View view) {
            Intent intent = new Intent(MainActivity9.this, MainActivity7.class);
            startActivity(intent);
    }
}