package com.example.aplikasitugasku;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity10 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main10);

        };public void imageButton22(View view) {
        Intent intent = new Intent(MainActivity10.this, MainActivity9.class);
        startActivity(intent);

    };public void imageButton23(View view) {
        Intent intent = new Intent(MainActivity10.this, MainActivity12.class);
        startActivity(intent);

    };public void imageButton24(View view) {
            Intent intent = new Intent(MainActivity10.this, MainActivity9.class);
            startActivity(intent);
    }
}