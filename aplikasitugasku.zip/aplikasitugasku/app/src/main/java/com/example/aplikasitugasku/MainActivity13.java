package com.example.aplikasitugasku;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity13 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main13);

        };public void imageButton14(View view) {
        Intent intent = new Intent(MainActivity13.this, MainActivity15.class);
        startActivity(intent);

    };public void imageButton13(View view) {
        Intent intent = new Intent(MainActivity13.this, MainActivity14.class);
        startActivity(intent);
    }
}